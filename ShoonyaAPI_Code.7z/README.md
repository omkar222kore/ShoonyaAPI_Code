# ShoonyaAPI_Code
Code for the algo trade
