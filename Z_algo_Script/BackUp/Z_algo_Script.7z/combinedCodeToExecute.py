import time
import datetime
import subprocess
import os

def wait_until(target_time):
    """Wait until the specified target time."""
    now = datetime.datetime.now()
    target_time = now.replace(hour=target_time.hour, minute=target_time.minute, second=0, microsecond=0)
    
    # If the target time is earlier today, schedule for tomorrow
    if target_time < now:
        target_time += datetime.timedelta(days=1)

    sleep_duration = (target_time - now).total_seconds()
    print(f"Waiting for {sleep_duration / 60:.2f} minutes until {target_time}.")
    time.sleep(sleep_duration)

def run_python_script(script_path):
    """Run a Python script using subprocess."""
    try:
        result = subprocess.run(["python", script_path], check=True, text=True, capture_output=True)
        print(result.stdout)
        if result.stderr:
            print(result.stderr)
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running {script_path}: {e}")

def clear_csv_files(directory):
    """Delete all CSV files in the specified directory."""
    for file_name in os.listdir(directory):
        if file_name.endswith('.csv'):
            file_path = os.path.join(directory, file_name)
            try:
                os.remove(file_path)
                print(f"Deleted {file_path}")
            except Exception as e:
                print(f"Failed to delete {file_path}: {e}")

def main():
    # Define paths to the Python scripts
    script1 = "E:\\Z_algo_Script\\downloadCSV.py"
    script2 = "E:\\Z_algo_Script\\punch_orders.py"
    downloads_folder = "C:\\Users\\omkar\\Downloads"

    # Set target time and wait duration
    target_hour = 20  # Set to the desired hour (24-hour format)
    target_minute =25  # Set to the desired minute
    wait_seconds = 2  # Set wait duration in seconds

    # Wait until the specified target time
    wait_until(datetime.time(target_hour, target_minute))

    # Run the first script
    print(f"Running {script1}...")
    run_python_script(script1)

    # Wait for the specified duration
    print(f"Waiting for {wait_seconds} seconds...")
    time.sleep(wait_seconds)

    # Run the second script
    print(f"Running {script2}...")
    run_python_script(script2)

    # Clear CSV files in the Downloads folder
    print("Clearing CSV files in Downloads folder...")
    clear_csv_files(downloads_folder)

if __name__ == "__main__":
    main()
